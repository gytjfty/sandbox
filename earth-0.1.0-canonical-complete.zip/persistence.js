import { SAVE } from './config.js';
import { createWorld, validateWorld } from './material.js';
export class WorldStore {
  constructor(notify = () => {}) { this.notify = notify; this.database = null; this.queue = Promise.resolve(); }
  open(name, create) {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(name, 1);
      request.onupgradeneeded = () => {
        if (create) request.result.createObjectStore(SAVE.store);
        else request.transaction.abort();
      };
      request.onerror = () => {
        if (!create && request.error?.name === 'AbortError') resolve(null);
        else reject(request.error);
      };
      request.onblocked = () => this.notify('Close other game tabs to open the save.');
      request.onsuccess = () => resolve(request.result);
    });
  }
  read(database) {
    return new Promise((resolve, reject) => {
      if (!database.objectStoreNames.contains(SAVE.store)) return resolve(null);
      const request = database.transaction(SAVE.store).objectStore(SAVE.store).get(SAVE.key);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  write(world) {
    validateWorld(world);
    const snapshot = structuredClone(world);
    const run = () => new Promise((resolve, reject) => {
      const transaction = this.database.transaction(SAVE.store, 'readwrite');
      transaction.objectStore(SAVE.store).put(snapshot, SAVE.key);
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error || Error('Save failed.'));
      transaction.onabort = () => reject(transaction.error || Error('Save aborted.'));
    });
    const result = this.queue.then(run);
    this.queue = result.catch(() => {});
    return result;
  }
  async load() {
    this.database = await this.open(SAVE.database, true);
    const current = await this.read(this.database);
    if (current !== undefined) return validateWorld(current);
    let world = createWorld(), imported = false;
    for (const name of SAVE.legacyDatabases) {
      const database = await this.open(name, false);
      if (!database) continue;
      let old;
      try { old = await this.read(database); } finally { database.close(); }
      if (old === undefined) continue;
      if (!old || typeof old !== 'object') throw Error('Invalid legacy save record.');
      let operations;
      if (name === 'earth-rock-conservation-v1') {
        if (old.format !== 'earth-rock-v1' || !Array.isArray(old.edits)) throw Error('Invalid legacy rock save.');
        operations = old.edits.map(edit => ({ x: edit.x, y: edit.y, z: edit.z, r: edit.r,
          kind: 'cut', units: edit.removedUnits }));
      } else {
        const format = name === 'earth-rock-building-v1' ? 'earth-building-v1' : 'earth-backfill-v1';
        if (old.format !== format || !Array.isArray(old.ops)) throw Error('Invalid legacy building save.');
        operations = old.ops.map(edit => name === 'earth-rock-placement-v1' && edit.kind === 'fill'
          ? { ...edit, clipToPlanet: true } : edit);
      }
      world = { ...world, cellSize: old.cellSize, density: old.density,
        baselineCount: old.baselineCount, inventoryUnits: old.inventoryUnits, ops: operations };
      validateWorld(world); imported = true; break;
    }
    if (!imported) {
      const database = await this.open(SAVE.volumeDatabase, false);
      if (database) {
        let edits = [];
        try {
          if (database.objectStoreNames.contains('edits')) {
            edits = await new Promise((resolve, reject) => {
              const request = database.transaction('edits').objectStore('edits').getAll();
              request.onsuccess = () => resolve(request.result);
              request.onerror = () => reject(request.error);
            });
          }
        } finally { database.close(); }
        world.ops = edits.map(edit => ({ x: edit.x, y: edit.y, z: edit.z, r: edit.r, kind: 'cut', units: 0 }));
        world.baselineCount = world.ops.length;
      }
    }
    await this.write(world);
    return world;
  }
}

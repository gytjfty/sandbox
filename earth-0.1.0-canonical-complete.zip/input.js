import { CONFIG } from './config.js';
import { COMMAND } from './protocol.js';
import { lookDirection } from './view-math.js';
const $ = selector => document.querySelector(selector);
export class InputController {
  constructor(canvas, context) {
    this.canvas = canvas; this.context = context; this.keys = new Set(); this.held = false;
    this.radius = CONFIG.initialDigRadius; this.lastInput = 0; this.touches = new Map();
    this.bindKeyboard(); this.bindPointer(); this.bindTouch();
  }
  flush() {
    this.context.send(COMMAND.INPUT, { keys: [...this.keys], held: this.held, f: this.context.forward() });
    this.lastInput = performance.now();
  }
  refresh(now) { if (now - this.lastInput > CONFIG.inputRefreshMs) this.flush(); }
  clear() { this.keys.clear(); this.held = false; this.flush(); }
  stopDigging() { this.held = false; this.flush(); }
  look(dx, dy) {
    const player = this.context.player(); if (!player) return;
    this.context.setForward(lookDirection(this.context.forward(), player, dx, dy)); this.flush();
  }
  bindKeyboard() {
    const context = this.context;
    addEventListener('keydown', event => {
      if (event.target instanceof HTMLInputElement) return;
      if (['Tab', 'Space'].includes(event.code)) event.preventDefault();
      if (context.editor.open && (event.ctrlKey || event.metaKey)) {
        if (event.code === 'KeyD') {
          event.preventDefault(); if (!event.repeat) { context.editor.add(); context.editorUI.render(); } return;
        }
        if (event.code === 'KeyZ') {
          event.preventDefault(); if (!event.repeat) { context.editor.history(event.shiftKey); context.editorUI.render(); } return;
        }
      }
      this.keys.add(event.code); this.flush(); if (event.repeat) return;
      switch (event.code) {
        case 'Tab': case 'KeyR': context.toggleEditor(); break;
        case 'KeyP': context.send(COMMAND.PAUSE); break;
        case 'KeyJ': context.send(COMMAND.FLY); break;
        case 'KeyG': context.send(COMMAND.RECOVER); break;
        case 'KeyB': context.send(COMMAND.BACKUP); break;
        case 'KeyE': context.send(COMMAND.DIG); break;
        case 'Space': context.send(COMMAND.JUMP); break;
        case 'KeyM': {
          const state = context.state();
          if (state) context.note(`${state.inventory.toLocaleString()} m³ rock · ${(BigInt(state.inventory) * BigInt(CONFIG.density)).toLocaleString()} kg`);
          break;
        }
        case 'Delete':
          if (context.editor.open) { context.editor.remove(); context.editorUI.render(); } break;
        case 'BracketLeft': case 'BracketRight':
          if (!context.editor.open) {
            this.radius = event.code === 'BracketRight' ? Math.min(CONFIG.maxDigRadius, this.radius * 2)
              : Math.max(CONFIG.minDigRadius, this.radius / 2);
            context.send(COMMAND.RADIUS, { value: this.radius }); context.note(`Dig radius ${this.radius} m`);
          }
          break;
      }
    });
    addEventListener('keyup', event => { this.keys.delete(event.code); this.flush(); });
    addEventListener('blur', () => this.clear());
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.clear(); });
  }
  bindPointer() {
    const canvas = this.canvas, context = this.context;
    canvas.oncontextmenu = event => event.preventDefault();
    canvas.onclick = () => {
      if (context.editor.open || document.pointerLockElement === canvas) return;
      try { canvas.requestPointerLock()?.catch?.(() => context.note('Click to capture mouse.')); }
      catch (error) { context.note(error.message); }
    };
    canvas.onmousedown = event => {
      if (context.editor.open) {
        if (event.button === 0) context.editorUI.selectAt(event.clientX, event.clientY);
        return;
      }
      if (event.button === 0 && document.pointerLockElement === canvas) {
        this.held = true; this.flush(); context.send(COMMAND.DIG);
      }
    };
    addEventListener('mouseup', event => { if (event.button === 0) this.stopDigging(); });
    document.addEventListener('pointerlockchange', () => this.stopDigging());
    addEventListener('mousemove', event => {
      if (document.pointerLockElement === canvas
        || (context.editor.open && (event.buttons & 2) && event.target === canvas)) {
        this.look(event.movementX, event.movementY);
      }
    });
  }
  bindTouch() {
    const canvas = this.canvas, context = this.context;
    const movement = ['KeyW', 'KeyS', 'KeyA', 'KeyD'];
    canvas.onpointerdown = event => {
      if (event.pointerType === 'mouse') return;
      canvas.setPointerCapture(event.pointerId);
      this.touches.set(event.pointerId, { x: event.clientX, y: event.clientY, sx: event.clientX,
        sy: event.clientY, left: event.clientX < innerWidth * 0.4 });
    };
    canvas.onpointermove = event => {
      const touch = this.touches.get(event.pointerId); if (!touch) return;
      if (touch.left) {
        for (const key of movement) this.keys.delete(key);
        if (event.clientY < touch.sy - 12) this.keys.add('KeyW');
        if (event.clientY > touch.sy + 12) this.keys.add('KeyS');
        if (event.clientX < touch.sx - 12) this.keys.add('KeyA');
        if (event.clientX > touch.sx + 12) this.keys.add('KeyD');
        this.flush();
      } else this.look(event.clientX - touch.x, event.clientY - touch.y);
      touch.x = event.clientX; touch.y = event.clientY;
    };
    const end = event => {
      if (this.touches.get(event.pointerId)?.left) { for (const key of movement) this.keys.delete(key); this.flush(); }
      this.touches.delete(event.pointerId);
    };
    canvas.onpointerup = canvas.onpointercancel = end;
    $('#touchEditor').onclick = () => context.toggleEditor();
    $('#touchRecover').onclick = () => context.send(COMMAND.RECOVER);
    $('#touchFly').onclick = () => context.send(COMMAND.FLY);
    $('#touchDig').onpointerdown = event => {
      event.preventDefault(); event.target.setPointerCapture(event.pointerId);
      this.held = true; this.flush(); context.send(COMMAND.DIG);
    };
    $('#touchDig').onpointerup = $('#touchDig').onpointercancel = () => this.stopDigging();
    for (const button of document.querySelectorAll('[data-key]')) {
      button.onpointerdown = event => {
        event.preventDefault(); button.setPointerCapture(event.pointerId);
        this.keys.add(button.dataset.key); this.flush();
        if (button.dataset.key === 'Space') context.send(COMMAND.JUMP);
      };
      button.onpointerup = button.onpointercancel = () => { this.keys.delete(button.dataset.key); this.flush(); };
    }
  }
}

import { CONFIG, SAVE } from './config.js';
const volumeCache = new Map();
export function sphereUnits(radius) {
  if (!Number.isFinite(radius) || radius < CONFIG.minPartRadius || radius > CONFIG.maxPartRadius) {
    throw Error(`Part radius must be ${CONFIG.minPartRadius}–${CONFIG.maxPartRadius} m.`);
  }
  if (volumeCache.has(radius)) return volumeCache.get(radius);
  let units = 0;
  for (let x = Math.floor(-radius); x < Math.ceil(radius); x++) {
    for (let y = Math.floor(-radius); y < Math.ceil(radius); y++) {
      const heightSquared = radius * radius - (x + 0.5) ** 2 - (y + 0.5) ** 2;
      if (heightSquared < 0) continue;
      const extent = Math.sqrt(heightSquared);
      units += Math.max(0, Math.floor(extent - 0.5) - Math.ceil(-extent - 0.5) + 1);
    }
  }
  volumeCache.set(radius, units);
  return units;
}
export function createWorld() {
  return { format: SAVE.format, cellSize: CONFIG.accountingCellSize, density: CONFIG.density,
    baselineCount: 0, inventoryUnits: 0, ops: [], bodies: [] };
}
export function validateWorld(world) {
  if (!world || world.format !== SAVE.format || world.cellSize !== CONFIG.accountingCellSize
    || world.density !== CONFIG.density || !Array.isArray(world.ops)
    || world.ops.length > CONFIG.maxTerrainOperations || !Array.isArray(world.bodies)
    || world.bodies.length > CONFIG.maxPhysicalParts || !Number.isSafeInteger(world.baselineCount)
    || world.baselineCount < 0 || world.baselineCount > world.ops.length
    || !Number.isSafeInteger(world.inventoryUnits) || world.inventoryUnits < 0) {
    throw Error('Invalid world schema; original data retained.');
  }
  let total = 0;
  for (let i = 0; i < world.ops.length; i++) {
    const operation = world.ops[i];
    if (![operation.x, operation.y, operation.z, operation.r].every(Number.isFinite)
      || operation.r <= 0 || !['cut', 'fill'].includes(operation.kind)
      || !Number.isSafeInteger(operation.units) || operation.units < 0
      || (operation.clipToPlanet !== undefined
        && (typeof operation.clipToPlanet !== 'boolean' || operation.kind !== 'fill'))
      || (i < world.baselineCount && (operation.kind !== 'cut' || operation.units !== 0))) {
      throw Error('Invalid terrain operation.');
    }
    total += operation.kind === 'cut' ? operation.units : -operation.units;
    if (!Number.isSafeInteger(total) || total < 0) throw Error('Invalid historical terrain balance.');
  }
  const ids = new Set();
  let parts = 0;
  for (const body of world.bodies) {
    if (typeof body.id !== 'string' || ids.has(body.id)
      || !['p', 'v', 'w'].every(key => Array.isArray(body[key]) && body[key].length === 3
        && body[key].every(Number.isFinite)) || body.units !== sphereUnits(body.r)) {
      throw Error('Invalid body/material record.');
    }
    ids.add(body.id); parts += body.units;
  }
  if (!Number.isSafeInteger(parts) || !Number.isSafeInteger(world.inventoryUnits + parts)
    || world.inventoryUnits + parts !== total) throw Error('Material ledger mismatch.');
  return world;
}

import { CONFIG } from './config.js';
export const R = CONFIG.worldRadius;
export function solidAt(position, operations) {
  const base = position.reduce((sum, value) => sum + value * value, 0) <= R * R;
  let solid = base;
  for (const operation of operations) {
    if ((!operation.clipToPlanet || base) && inside(operation, ...position)) {
      solid = operation.kind === 'fill';
    }
  }
  return solid;
}
export function field(position, operations) {
  const planet = Math.hypot(...position) - R;
  let distance = planet;
  for (const operation of operations) {
    const sphere = Math.hypot(position[0] - operation.x, position[1] - operation.y,
      position[2] - operation.z) - operation.r;
    distance = operation.kind === 'cut' ? Math.max(distance, -sphere)
      : Math.min(distance, operation.clipToPlanet ? Math.max(sphere, planet) : sphere);
  }
  return distance;
}
export function sphereRay(origin, direction, centre, radius) {
  const delta = centre.map((value, i) => value - origin[i]);
  const along = delta.reduce((sum, value, i) => sum + value * direction[i], 0);
  const discriminant = radius * radius
    - delta.reduce((sum, value, i) => sum + (value - direction[i] * along) ** 2, 0);
  if (discriminant < 0) return null;
  let distance = along - Math.sqrt(discriminant);
  if (distance < 0.001) distance = along + Math.sqrt(discriminant);
  return distance >= 0.001 ? distance : null;
}
export function terrainRay(origin, direction, operations, limit = 100) {
  if (solidAt(origin.map((value, i) => value + direction[i] * 0.001), operations)) return 0.001;
  const events = [], altitude = Math.hypot(...origin) - R;
  const b = origin.reduce((sum, value, i) => sum + value * direction[i], 0);
  const c = altitude * (2 * R + altitude), discriminant = b * b - c;
  const record = value => { if (value > 0.00101 && value <= limit) events.push(value); };
  if (discriminant >= 0) {
    const root = Math.sqrt(discriminant);
    record(c > 0 && b < 0 ? c / (-b + root) : -b - root);
    record(-b + root);
  }
  for (const operation of operations) {
    const delta = [operation.x - origin[0], operation.y - origin[1], operation.z - origin[2]];
    const along = delta.reduce((sum, value, i) => sum + value * direction[i], 0);
    const h = operation.r * operation.r
      - delta.reduce((sum, value, i) => sum + (value - along * direction[i]) ** 2, 0);
    if (h >= 0) { record(along - Math.sqrt(h)); record(along + Math.sqrt(h)); }
  }
  events.sort((a, b) => a - b);
  for (const distance of events) {
    const sample = distance + Math.max(0.00001, distance * 2e-12);
    if (solidAt(origin.map((value, i) => value + direction[i] * sample), operations)) return distance;
  }
  return null;
}
function inside(operation, x, y, z) {
  return (x - operation.x) ** 2 + (y - operation.y) ** 2 + (z - operation.z) ** 2 <= operation.r ** 2;
}
function sphereBox(operation, x, y, z, size) {
  let near = 0, far = 0;
  for (const [value, low] of [[operation.x, x], [operation.y, y], [operation.z, z]]) {
    const high = low + size;
    const nearest = value < low ? low - value : value > high ? value - high : 0;
    near += nearest * nearest;
    far += Math.max(Math.abs(value - low), Math.abs(value - high)) ** 2;
  }
  return near > operation.r ** 2 ? 0 : far <= operation.r ** 2 ? 2 : 1;
}
export function measureChange(edit, previous, budget = CONFIG.maxAccountingVisits) {
  let visits = 0;
  const minimum = [edit.x - edit.r, edit.y - edit.r, edit.z - edit.r].map(Math.floor);
  let size = 1;
  while (size < Math.max(edit.x + edit.r - minimum[0], edit.y + edit.r - minimum[1],
    edit.z + edit.r - minimum[2])) size *= 2;
  const planet = { x: 0, y: 0, z: 0, r: R }, wantSolid = edit.kind === 'cut';
  function visit(x, y, z, side, candidates) {
    if (++visits > budget) throw Error('Accounting budget exceeded; use a smaller cut. Nothing committed.');
    let change = sphereBox(edit, x, y, z, side);
    if (!change) return 0;
    const ground = sphereBox(planet, x, y, z, side);
    if (edit.clipToPlanet && ground === 0) return 0;
    if (edit.clipToPlanet && ground === 1) change = 1;
    let state = ground;
    const nearby = [];
    for (const operation of candidates) {
      const coverage = sphereBox(operation, x, y, z, side);
      if (!coverage || (operation.clipToPlanet && ground === 0)) continue;
      nearby.push(operation);
      if (operation.kind === 'cut') {
        if (coverage === 2) state = 0;
        else if (state === 2) state = 1;
      } else {
        if (coverage === 2) state = operation.clipToPlanet ? ground : 2;
        else if (state === 0) state = 1;
      }
    }
    if ((wantSolid && state === 0) || (!wantSolid && state === 2)) return 0;
    if (change === 2 && ((wantSolid && state === 2) || (!wantSolid && state === 0))) return side ** 3;
    if (side === 1) {
      const a = x + 0.5, b = y + 0.5, c = z + 0.5;
      return inside(edit, a, b, c) && (!edit.clipToPlanet || a * a + b * b + c * c <= R * R)
        && solidAt([a, b, c], nearby) === wantSolid ? 1 : 0;
    }
    let units = 0;
    const half = side / 2;
    for (let a = 0; a < 2; a++) for (let b = 0; b < 2; b++) for (let c = 0; c < 2; c++) {
      units += visit(x + a * half, y + b * half, z + c * half, half, nearby);
    }
    return units;
  }
  return visit(...minimum, size, previous);
}
export function buildTree(operations) {
  const flat = [];
  function build(items) {
    const index = flat.length / 12;
    flat.push(...Array(12).fill(0));
    const low = [Infinity, Infinity, Infinity], high = [-Infinity, -Infinity, -Infinity];
    for (const operation of items) {
      const centre = [operation.x, operation.y, operation.z];
      for (let axis = 0; axis < 3; axis++) {
        low[axis] = Math.min(low[axis], centre[axis] - operation.r - 0.02);
        high[axis] = Math.max(high[axis], centre[axis] + operation.r + 0.02);
      }
    }
    for (let axis = 0; axis < 3; axis++) {
      flat[index * 12 + axis] = low[axis]; flat[index * 12 + 4 + axis] = high[axis];
    }
    if (items.length === 1) {
      const operation = items[0];
      flat[index * 12 + 7] = operation.order + 1 + (operation.clipToPlanet ? 0.25 : 0);
      flat[index * 12 + 8] = operation.x; flat[index * 12 + 9] = operation.y;
      flat[index * 12 + 10] = operation.z;
      flat[index * 12 + 11] = operation.kind === 'fill' ? -operation.r : operation.r;
    } else {
      let axis = 0;
      for (let i = 1; i < 3; i++) if (high[i] - low[i] > high[axis] - low[axis]) axis = i;
      const key = ['x', 'y', 'z'][axis];
      items.sort((a, b) => a[key] - b[key]);
      const middle = items.length >> 1;
      build(items.slice(0, middle)); build(items.slice(middle));
    }
    flat[index * 12 + 3] = flat.length / 12;
  }
  if (operations.length) build(operations.map((operation, order) => ({ ...operation, order })));
  return new Float64Array(flat);
}
